import React from "react";

export default function HistoryLog({ entries, onClear }) {
  if (entries.length === 0) return null;

  return (
    <div style={{ marginTop: 32 }}>
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
        <p style={{ fontSize: 13, color: "var(--ink-soft)" }}>Session history ({entries.length})</p>
        <button
          onClick={onClear}
          style={{
            fontSize: 12,
            background: "none",
            border: "1px solid var(--line-strong)",
            borderRadius: 999,
            padding: "4px 12px",
            color: "var(--ink-soft)",
          }}
        >
          Clear
        </button>
      </div>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {entries.slice().reverse().map((e, i) => (
          <div
            key={i}
            style={{
              display: "flex",
              justifyContent: "space-between",
              fontSize: 13,
              padding: "8px 12px",
              background: "var(--surface)",
              border: "1px solid var(--line)",
              borderRadius: 8,
            }}
          >
            <span className="mono" style={{ color: "var(--ink-faint)", textTransform: "uppercase", fontSize: 11, marginRight: 10 }}>
              {e.mode}
            </span>
            <span style={{ flex: 1 }}>{e.question}</span>
            <span style={{ color: "var(--ink-faint)" }}>{e.result.confidence}</span>
          </div>
        ))}
      </div>
    </div>
  );
}
