import React, { useState } from "react";
import UploadSlot from "./UploadSlot.jsx";
import AnswerReadout from "./AnswerReadout.jsx";
import { compareImages } from "../api.js";

export default function CompareView({ onLogged }) {
  const [fileA, setFileA] = useState(null);
  const [fileB, setFileB] = useState(null);
  const [question, setQuestion] = useState("What changed between these two images?");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);

  async function handleCompare() {
    if (!fileA || !fileB) { setError("Upload both Image A and Image B."); return; }
    setError("");
    setLoading(true);
    setResult(null);
    try {
      const data = await compareImages(fileA, fileB, question);
      setResult(data);
      onLogged?.({ mode: "compare", question, result: data });
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
        <UploadSlot label="Image A — earlier" file={fileA} onChange={setFileA} />
        <UploadSlot label="Image B — later" file={fileB} onChange={setFileB} />
      </div>

      <div style={{ display: "flex", gap: 12, marginBottom: 16 }}>
        <input
          value={question}
          onChange={(e) => setQuestion(e.target.value)}
          placeholder="What changed between these images?"
          style={{
            flex: 1,
            padding: 12,
            borderRadius: "var(--radius)",
            border: "1px solid var(--line-strong)",
            fontSize: 14,
          }}
        />
        <button
          onClick={handleCompare}
          disabled={loading}
          style={{
            background: "var(--signal-strong)",
            color: "white",
            border: "none",
            borderRadius: "var(--radius)",
            padding: "0 24px",
            fontSize: 14,
            fontWeight: 500,
            opacity: loading ? 0.7 : 1,
          }}
        >
          {loading ? "Comparing…" : "Compare"}
        </button>
      </div>

      <p style={{ fontSize: 12, color: "var(--ink-faint)", marginBottom: 20 }}>
        Note: this compares visual content only — it does not confirm real acquisition dates,
        so upload images of the same area/extent for a meaningful result.
      </p>

      {error && <p style={{ color: "var(--danger)", fontSize: 13, marginBottom: 16 }}>{error}</p>}

      {result && <AnswerReadout result={result} questionAsked={question} />}
    </div>
  );
}
