import React, { useRef, useState } from "react";

const MAX_MB = 20;
const ALLOWED = ["image/jpeg", "image/png", "image/tiff"];

/**
 * A single image upload slot: drag/drop or click-to-browse, with a live
 * preview and lightweight client-side validation (the backend re-validates
 * everything again — this is just for fast user feedback).
 */
export default function UploadSlot({ label, file, onChange, imgRef }) {
  const inputRef = useRef(null);
  const [dragOver, setDragOver] = useState(false);
  const [error, setError] = useState("");
  const previewUrl = file ? URL.createObjectURL(file) : null;

  function validateAndSet(candidate) {
    setError("");
    if (!candidate) return;
    if (!ALLOWED.includes(candidate.type)) {
      setError("Unsupported format. Use JPG, PNG, or TIFF.");
      return;
    }
    if (candidate.size / (1024 * 1024) > MAX_MB) {
      setError(`File is too large (max ${MAX_MB}MB).`);
      return;
    }
    onChange(candidate);
  }

  return (
    <div>
      <p style={{ fontSize: 13, color: "var(--ink-soft)", marginBottom: 8 }}>{label}</p>
      <div
        onClick={() => inputRef.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setDragOver(true); }}
        onDragLeave={() => setDragOver(false)}
        onDrop={(e) => {
          e.preventDefault();
          setDragOver(false);
          validateAndSet(e.dataTransfer.files?.[0]);
        }}
        style={{
          border: `1.5px dashed ${dragOver ? "var(--signal)" : "var(--line-strong)"}`,
          borderRadius: "var(--radius-lg)",
          background: dragOver ? "var(--signal-tint)" : "var(--surface)",
          minHeight: previewUrl ? "auto" : 220,
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          cursor: "pointer",
          overflow: "hidden",
          transition: "border-color 120ms, background 120ms",
        }}
      >
        {previewUrl ? (
          <img
            ref={imgRef}
            src={previewUrl}
            alt={`${label} preview`}
            style={{ width: "100%", display: "block", maxHeight: 420, objectFit: "contain", background: "var(--surface-sunken)" }}
          />
        ) : (
          <div style={{ textAlign: "center", padding: 24, color: "var(--ink-faint)" }}>
            <p style={{ fontSize: 14, marginBottom: 4 }}>Drop satellite image here</p>
            <p style={{ fontSize: 12 }}>or click to browse — JPG, PNG, TIFF, up to {MAX_MB}MB</p>
          </div>
        )}
      </div>
      <input
        ref={inputRef}
        type="file"
        accept="image/jpeg,image/png,image/tiff"
        style={{ display: "none" }}
        onChange={(e) => validateAndSet(e.target.files?.[0])}
      />
      {error && (
        <p style={{ fontSize: 12, color: "var(--danger)", marginTop: 6 }}>{error}</p>
      )}
      {file && (
        <p className="mono" style={{ fontSize: 11, color: "var(--ink-faint)", marginTop: 6 }}>
          {file.name} · {(file.size / (1024 * 1024)).toFixed(1)}MB
        </p>
      )}
    </div>
  );
}
