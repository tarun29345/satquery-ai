import React from "react";

export default function Header({ apiOnline }) {
  return (
    <header
      style={{
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        padding: "20px 32px",
        borderBottom: "1px solid var(--line)",
      }}
    >
      <div style={{ display: "flex", alignItems: "baseline", gap: 12 }}>
        <h1 style={{ fontSize: 22, letterSpacing: "-0.01em" }}>SatQuery AI</h1>
        <span style={{ color: "var(--ink-faint)", fontSize: 14 }}>
          Remote sensing intelligence assistant
        </span>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 8, fontSize: 13 }}>
        <span
          style={{
            width: 8,
            height: 8,
            borderRadius: "50%",
            background: apiOnline ? "var(--signal)" : "var(--danger)",
            display: "inline-block",
          }}
        />
        <span className="mono" style={{ color: "var(--ink-soft)" }}>
          {apiOnline ? "backend online" : "backend unreachable"}
        </span>
      </div>
    </header>
  );
}
