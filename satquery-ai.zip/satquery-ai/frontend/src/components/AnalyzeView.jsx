import React, { useRef, useState } from "react";
import UploadSlot from "./UploadSlot.jsx";
import AnswerReadout from "./AnswerReadout.jsx";
import { analyzeImage, analyzeRegion } from "../api.js";

const SUGGESTIONS = [
  "Describe this image",
  "Is there a water body?",
  "Are there buildings?",
  "What type of land cover is visible?",
  "Are there roads?",
];

export default function AnalyzeView({ onLogged }) {
  const [file, setFile] = useState(null);
  const [question, setQuestion] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [result, setResult] = useState(null);
  const [askedQuestion, setAskedQuestion] = useState("");

  const [regionMode, setRegionMode] = useState(false);
  const [box, setBox] = useState(null); // {x1,y1,x2,y2} in NATURAL image pixels
  const dragStart = useRef(null);
  const imgRef = useRef(null);

  function handleFileChange(f) {
    setFile(f);
    setResult(null);
    setBox(null);
  }

  function toNaturalCoords(clientX, clientY) {
    const img = imgRef.current;
    const rect = img.getBoundingClientRect();
    const scaleX = img.naturalWidth / rect.width;
    const scaleY = img.naturalHeight / rect.height;
    return {
      x: (clientX - rect.left) * scaleX,
      y: (clientY - rect.top) * scaleY,
    };
  }

  function handleMouseDown(e) {
    if (!regionMode || !imgRef.current) return;
    dragStart.current = toNaturalCoords(e.clientX, e.clientY);
    setBox(null);
  }

  function handleMouseMove(e) {
    if (!regionMode || !dragStart.current) return;
    const current = toNaturalCoords(e.clientX, e.clientY);
    setBox({
      x1: Math.min(dragStart.current.x, current.x),
      y1: Math.min(dragStart.current.y, current.y),
      x2: Math.max(dragStart.current.x, current.x),
      y2: Math.max(dragStart.current.y, current.y),
    });
  }

  function handleMouseUp() {
    dragStart.current = null;
  }

  async function handleAnalyze() {
    if (!file) { setError("Upload a satellite image first."); return; }
    if (!question.trim()) { setError("Type a question about the image."); return; }
    if (regionMode && !box) { setError("Drag a box on the image to select a region."); return; }

    setError("");
    setLoading(true);
    setResult(null);
    try {
      const data = regionMode
        ? await analyzeRegion(file, question, box)
        : await analyzeImage(file, question);
      setResult(data);
      setAskedQuestion(question);
      onLogged?.({ mode: regionMode ? "region" : "analyze", question, result: data });
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  // Overlay box position, converted back to DISPLAY (rendered) pixels for drawing.
  function getDisplayBox() {
    if (!box || !imgRef.current) return null;
    const img = imgRef.current;
    const rect = img.getBoundingClientRect();
    const scaleX = rect.width / img.naturalWidth;
    const scaleY = rect.height / img.naturalHeight;
    return {
      left: box.x1 * scaleX,
      top: box.y1 * scaleY,
      width: (box.x2 - box.x1) * scaleX,
      height: (box.y2 - box.y1) * scaleY,
    };
  }
  const displayBox = getDisplayBox();

  return (
    <div style={{ display: "grid", gridTemplateColumns: "1.1fr 1fr", gap: 28 }}>
      <div>
        <div
          style={{ position: "relative" }}
          onMouseDown={handleMouseDown}
          onMouseMove={handleMouseMove}
          onMouseUp={handleMouseUp}
        >
          <UploadSlot label="Satellite / aerial image" file={file} onChange={handleFileChange} imgRef={imgRef} />
          {displayBox && (
            <div
              style={{
                position: "absolute",
                left: displayBox.left,
                top: displayBox.top,
                width: displayBox.width,
                height: displayBox.height,
                border: "2px solid var(--signal)",
                background: "rgba(20, 107, 112, 0.12)",
                pointerEvents: "none",
              }}
            />
          )}
        </div>

        {file && (
          <label style={{ display: "flex", alignItems: "center", gap: 8, marginTop: 12, fontSize: 13, color: "var(--ink-soft)" }}>
            <input
              type="checkbox"
              checked={regionMode}
              onChange={(e) => { setRegionMode(e.target.checked); setBox(null); }}
            />
            Ask about a specific region — drag a box on the image
          </label>
        )}
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
        <div>
          <p style={{ fontSize: 13, color: "var(--ink-soft)", marginBottom: 8 }}>Ask SatQuery</p>
          <textarea
            value={question}
            onChange={(e) => setQuestion(e.target.value)}
            placeholder="What features are visible in this image?"
            rows={3}
            style={{
              width: "100%",
              padding: 12,
              borderRadius: "var(--radius)",
              border: "1px solid var(--line-strong)",
              fontSize: 14,
              resize: "vertical",
              background: "var(--surface)",
            }}
          />
          <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 8 }}>
            {SUGGESTIONS.map((s) => (
              <button
                key={s}
                onClick={() => setQuestion(s)}
                style={{
                  fontSize: 12,
                  border: "1px solid var(--line-strong)",
                  background: "var(--surface)",
                  borderRadius: 999,
                  padding: "5px 12px",
                  color: "var(--ink-soft)",
                }}
              >
                {s}
              </button>
            ))}
          </div>
        </div>

        <button
          onClick={handleAnalyze}
          disabled={loading}
          style={{
            background: "var(--signal-strong)",
            color: "white",
            border: "none",
            borderRadius: "var(--radius)",
            padding: "12px 20px",
            fontSize: 14,
            fontWeight: 500,
            opacity: loading ? 0.7 : 1,
          }}
        >
          {loading ? "Analyzing…" : "Analyze"}
        </button>

        {error && <p style={{ color: "var(--danger)", fontSize: 13 }}>{error}</p>}

        {result && <AnswerReadout result={result} questionAsked={askedQuestion} />}
      </div>
    </div>
  );
}
