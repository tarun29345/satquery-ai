import React from "react";

const CONFIDENCE_COLOR = {
  High: { fg: "var(--signal-strong)", bg: "var(--signal-tint)" },
  Medium: { fg: "var(--amber)", bg: "var(--amber-tint)" },
  Low: { fg: "var(--danger)", bg: "var(--danger-tint)" },
  Unknown: { fg: "var(--ink-soft)", bg: "var(--surface-sunken)" },
};

export default function AnswerReadout({ result, questionAsked }) {
  if (!result) return null;
  const conf = CONFIDENCE_COLOR[result.confidence] || CONFIDENCE_COLOR.Unknown;
  const q = result.quantitative;

  return (
    <div
      style={{
        background: "var(--surface)",
        border: "1px solid var(--line)",
        borderRadius: "var(--radius-lg)",
        padding: 24,
      }}
    >
      <p className="mono" style={{ fontSize: 11, color: "var(--ink-faint)", marginBottom: 10 }}>
        query: "{questionAsked}"
      </p>

      <h3 style={{ fontSize: 15, color: "var(--ink-soft)", fontWeight: 500, marginBottom: 8 }}>Answer</h3>
      <p style={{ fontSize: 16, marginBottom: 20 }}>{result.answer}</p>

      {result.observations?.length > 0 && (
        <div style={{ marginBottom: 20 }}>
          <h3 style={{ fontSize: 15, color: "var(--ink-soft)", fontWeight: 500, marginBottom: 8 }}>
            Observations
          </h3>
          <ul style={{ margin: 0, paddingLeft: 18 }}>
            {result.observations.map((obs, i) => (
              <li key={i} style={{ fontSize: 14, marginBottom: 4, color: "var(--ink)" }}>{obs}</li>
            ))}
          </ul>
        </div>
      )}

      <div style={{ display: "flex", flexWrap: "wrap", gap: 24, alignItems: "flex-start" }}>
        {result.features?.length > 0 && (
          <div>
            <p style={{ fontSize: 12, color: "var(--ink-faint)", marginBottom: 6 }}>Detected features</p>
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6 }}>
              {result.features.map((f, i) => (
                <span
                  key={i}
                  className="mono"
                  style={{
                    fontSize: 12,
                    background: "var(--surface-sunken)",
                    color: "var(--ink)",
                    padding: "4px 10px",
                    borderRadius: 999,
                  }}
                >
                  {f}
                </span>
              ))}
            </div>
          </div>
        )}

        {(result.location || result.region_label) && (
          <div>
            <p style={{ fontSize: 12, color: "var(--ink-faint)", marginBottom: 6 }}>Location in frame</p>
            <p className="mono" style={{ fontSize: 13 }}>{result.region_label || result.location}</p>
          </div>
        )}

        <div>
          <p style={{ fontSize: 12, color: "var(--ink-faint)", marginBottom: 6 }}>Confidence</p>
          <span
            className="mono"
            style={{ fontSize: 13, color: conf.fg, background: conf.bg, padding: "4px 10px", borderRadius: 6 }}
          >
            {result.confidence}
          </span>
        </div>

        {typeof result.latency_ms === "number" && (
          <div>
            <p style={{ fontSize: 12, color: "var(--ink-faint)", marginBottom: 6 }}>Response time</p>
            <p className="mono" style={{ fontSize: 13 }}>{result.latency_ms}ms</p>
          </div>
        )}
      </div>

      {q && <QuantitativeSection quantitative={q} />}
    </div>
  );
}

function QuantitativeSection({ quantitative }) {
  const bars = [
    { label: "Vegetation", pct: quantitative.vegetation_pct, color: "var(--signal-strong)" },
    { label: "Water", pct: quantitative.water_pct, color: "#2E5FA3" },
    { label: "Built-up", pct: quantitative.built_up_pct, color: "var(--amber)" },
    { label: "Other / bare", pct: quantitative.other_pct, color: "var(--ink-faint)" },
  ];

  return (
    <div style={{ marginTop: 24, paddingTop: 20, borderTop: "1px solid var(--line)" }}>
      <p style={{ fontSize: 13, color: "var(--ink-soft)", marginBottom: 4 }}>
        Quantitative estimate <span style={{ color: "var(--ink-faint)" }}>— pixel-level CV, independent of the AI answer above</span>
      </p>
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginTop: 12 }}>
        <div>
          {bars.map((b) => (
            <div key={b.label} style={{ marginBottom: 10 }}>
              <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 3 }}>
                <span style={{ color: "var(--ink-soft)" }}>{b.label}</span>
                <span className="mono">{b.pct}%</span>
              </div>
              <div style={{ height: 6, background: "var(--surface-sunken)", borderRadius: 999 }}>
                <div style={{ width: `${b.pct}%`, height: "100%", background: b.color, borderRadius: 999 }} />
              </div>
            </div>
          ))}
        </div>
        {quantitative.overlay_image_base64 && (
          <img
            src={quantitative.overlay_image_base64}
            alt="CV classification overlay"
            style={{ width: "100%", borderRadius: "var(--radius)", border: "1px solid var(--line)" }}
          />
        )}
      </div>
      <p style={{ fontSize: 11, color: "var(--ink-faint)", marginTop: 10 }}>{quantitative.disclaimer}</p>
    </div>
  );
}
