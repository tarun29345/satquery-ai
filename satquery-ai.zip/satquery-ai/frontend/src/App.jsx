import React, { useEffect, useState } from "react";
import Header from "./components/Header.jsx";
import AnalyzeView from "./components/AnalyzeView.jsx";
import CompareView from "./components/CompareView.jsx";
import HistoryLog from "./components/HistoryLog.jsx";
import { checkHealth } from "./api.js";

const TABS = [
  { id: "analyze", label: "Analyze image" },
  { id: "compare", label: "Compare two images" },
];

export default function App() {
  const [tab, setTab] = useState("analyze");
  const [apiOnline, setApiOnline] = useState(null);
  const [history, setHistory] = useState([]);

  useEffect(() => {
    checkHealth()
      .then(() => setApiOnline(true))
      .catch(() => setApiOnline(false));
  }, []);

  return (
    <div>
      <Header apiOnline={apiOnline} />

      <main style={{ maxWidth: 1080, margin: "0 auto", padding: "32px 32px 80px" }}>
        {apiOnline === false && (
          <div
            style={{
              background: "var(--danger-tint)",
              color: "var(--danger)",
              padding: "10px 16px",
              borderRadius: "var(--radius)",
              fontSize: 13,
              marginBottom: 20,
            }}
          >
            Can't reach the backend at localhost:8000. Make sure it's running
            (see README) — the app will keep working once it's back.
          </div>
        )}

        <div style={{ display: "flex", gap: 4, marginBottom: 28 }}>
          {TABS.map((t) => (
            <button
              key={t.id}
              onClick={() => setTab(t.id)}
              style={{
                padding: "9px 18px",
                fontSize: 14,
                border: "none",
                borderBottom: tab === t.id ? "2px solid var(--signal-strong)" : "2px solid transparent",
                background: "none",
                color: tab === t.id ? "var(--ink)" : "var(--ink-faint)",
                fontWeight: tab === t.id ? 500 : 400,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {tab === "analyze" && (
          <AnalyzeView onLogged={(e) => setHistory((h) => [...h, e])} />
        )}
        {tab === "compare" && (
          <CompareView onLogged={(e) => setHistory((h) => [...h, e])} />
        )}

        <HistoryLog entries={history} onClear={() => setHistory([])} />
      </main>
    </div>
  );
}
