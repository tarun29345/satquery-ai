/**
 * api.js
 * ------
 * The only file that knows about backend URLs and request shapes.
 * Components call these functions and never touch fetch() directly —
 * this makes it trivial to change the backend contract in one place.
 *
 * API_BASE resolves to:
 *   - "" (relative /api/...) during local dev — Vite's dev server proxy
 *     (see vite.config.js) forwards these to localhost:8000.
 *   - the real deployed backend URL in production, read from
 *     VITE_API_BASE_URL (set this in Vercel project settings > Environment
 *     Variables). Vercel itself does not run this FastAPI backend — it must
 *     be deployed separately (Render/Railway/Fly.io) and its URL put here.
 */
const API_BASE = import.meta.env.VITE_API_BASE_URL || "";

async function handleResponse(response) {
  const data = await response.json();
  if (!response.ok) {
    // FastAPI returns {"detail": "message"} on HTTPException - surface that.
    throw new Error(data.detail || "Something went wrong. Please try again.");
  }
  return data;
}

export async function analyzeImage(file, question) {
  const formData = new FormData();
  formData.append("image", file);
  formData.append("question", question);
  formData.append("query_type", "auto");

  const response = await fetch(`${API_BASE}/api/analyze`, { method: "POST", body: formData });
  return handleResponse(response);
}

export async function compareImages(fileA, fileB, question) {
  const formData = new FormData();
  formData.append("image_a", fileA);
  formData.append("image_b", fileB);
  formData.append("question", question);

  const response = await fetch(`${API_BASE}/api/compare`, { method: "POST", body: formData });
  return handleResponse(response);
}

export async function analyzeRegion(file, question, box) {
  const formData = new FormData();
  formData.append("image", file);
  formData.append("question", question);
  formData.append("x1", Math.round(box.x1));
  formData.append("y1", Math.round(box.y1));
  formData.append("x2", Math.round(box.x2));
  formData.append("y2", Math.round(box.y2));

  const response = await fetch(`${API_BASE}/api/analyze-region`, { method: "POST", body: formData });
  return handleResponse(response);
}

export async function checkHealth() {
  const response = await fetch(`${API_BASE}/health`);
  return handleResponse(response);
}
