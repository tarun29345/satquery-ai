/**
 * api.js
 * ------
 * The only file that knows about backend URLs and request shapes.
 * Components call these functions and never touch fetch() directly —
 * this makes it trivial to change the backend contract in one place.
 */

async function handleResponse(response) {
  const data = await response.json();
  if (!response.ok) {
    // FastAPI returns {"detail": "message"} on HTTPException - surface that.
    throw new Error(data.detail || "Something went wrong. Please try again.");
  }
  return data;
}

export async function analyzeImage(file, question) {
  const formData = new FormData();
  formData.append("image", file);
  formData.append("question", question);
  formData.append("query_type", "auto");

  const response = await fetch("/api/analyze", { method: "POST", body: formData });
  return handleResponse(response);
}

export async function compareImages(fileA, fileB, question) {
  const formData = new FormData();
  formData.append("image_a", fileA);
  formData.append("image_b", fileB);
  formData.append("question", question);

  const response = await fetch("/api/compare", { method: "POST", body: formData });
  return handleResponse(response);
}

export async function analyzeRegion(file, question, box) {
  const formData = new FormData();
  formData.append("image", file);
  formData.append("question", question);
  formData.append("x1", Math.round(box.x1));
  formData.append("y1", Math.round(box.y1));
  formData.append("x2", Math.round(box.x2));
  formData.append("y2", Math.round(box.y2));

  const response = await fetch("/api/analyze-region", { method: "POST", body: formData });
  return handleResponse(response);
}

export async function checkHealth() {
  const response = await fetch("/health");
  return handleResponse(response);
}
