"""
tests/test_cv_analysis.py
---------------------------
Tests the quantitative CV layer using SYNTHETIC images where we know the
exact ground-truth proportions (e.g. "exactly 25% of this image is blue"),
so we can check the heuristics are in the right ballpark rather than
just "doesn't crash".
"""
import sys
import os
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from services.cv_analysis import compute_quantitative_layers, compute_change_delta


def _half_water_half_land():
    """Top half strongly blue (water-like), bottom half neutral gray."""
    arr = np.full((100, 100, 3), 180, dtype=np.uint8)
    arr[0:50, :] = [30, 50, 170]  # RGB - strong blue
    return Image.fromarray(arr, mode="RGB")


def _mostly_vegetation():
    """90% strongly green (vegetation-like), 10% neutral gray."""
    arr = np.full((100, 100, 3), 180, dtype=np.uint8)
    arr[0:90, :] = [30, 150, 30]  # RGB - strong green
    return Image.fromarray(arr, mode="RGB")


def test_water_detection_roughly_half():
    layers = compute_quantitative_layers(_half_water_half_land())
    assert 35 <= layers["water_pct"] <= 65, f"expected ~50% water, got {layers['water_pct']}%"


def test_vegetation_detection_majority():
    layers = compute_quantitative_layers(_mostly_vegetation())
    assert layers["vegetation_pct"] > 50, f"expected majority vegetation, got {layers['vegetation_pct']}%"


def test_percentages_sum_close_to_100():
    layers = compute_quantitative_layers(_half_water_half_land())
    total = layers["water_pct"] + layers["vegetation_pct"] + layers["built_up_pct"] + layers["other_pct"]
    assert 99 <= total <= 101


def test_overlay_is_valid_base64_png():
    layers = compute_quantitative_layers(_half_water_half_land())
    assert layers["overlay_image_base64"].startswith("data:image/png;base64,")


def test_identical_images_have_zero_delta():
    img = _mostly_vegetation()
    layers_a = compute_quantitative_layers(img)
    layers_b = compute_quantitative_layers(img)
    delta = compute_change_delta(layers_a, layers_b)
    assert delta["vegetation_delta_pct"] == 0.0
    assert delta["water_delta_pct"] == 0.0


def test_vegetation_loss_reflected_in_delta():
    before = _mostly_vegetation()
    after = _half_water_half_land()  # much less vegetation
    layers_a = compute_quantitative_layers(before)
    layers_b = compute_quantitative_layers(after)
    delta = compute_change_delta(layers_a, layers_b)
    assert delta["vegetation_delta_pct"] < 0, "expected a negative vegetation delta (loss)"
