"""
tests/test_routes_integration.py
-----------------------------------
End-to-end tests of the actual HTTP routes using FastAPI's TestClient.
We mock ONLY services.vision_service.query_vision_model (the one function
that makes a real network call) - everything else runs for real: file
validation, image decoding, prompt building, response parsing, and the
CV quantitative layer. This proves the whole pipeline is wired correctly
without needing a real GEMINI_API_KEY or network access, so it runs in CI.
"""
import io
import sys
import os
import numpy as np
from PIL import Image
from fastapi.testclient import TestClient
from unittest.mock import patch

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from main import app

client = TestClient(app)

FAKE_MODEL_RESPONSE = """ANSWER: Yes, a water body is visible in the upper portion of the image.
OBSERVATIONS: Smooth blue region | Defined boundary
FEATURES: water, vegetation
LOCATION: upper region
CONFIDENCE: Medium"""


def _make_image_bytes(w=200, h=200, color=(40, 120, 200)):
    arr = np.full((h, w, 3), color, dtype=np.uint8)
    img = Image.fromarray(arr, mode="RGB")
    buf = io.BytesIO()
    img.save(buf, format="JPEG")
    buf.seek(0)
    return buf


def test_health_endpoint():
    response = client.get("/health")
    assert response.status_code == 200
    assert "ai_configured" in response.json()


@patch("routes.analyze.query_vision_model", return_value=FAKE_MODEL_RESPONSE)
def test_analyze_endpoint_full_pipeline(mock_query):
    image_bytes = _make_image_bytes()
    response = client.post(
        "/api/analyze",
        files={"image": ("test.jpg", image_bytes, "image/jpeg")},
        data={"question": "Is there a water body?", "query_type": "auto"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["confidence"] == "Medium"
    assert "water" in data["features"]
    assert data["query_type_used"] == "water"  # auto-routed correctly
    assert data["quantitative"] is not None
    assert "vegetation_pct" in data["quantitative"]
    mock_query.assert_called_once()


def test_analyze_endpoint_rejects_empty_question():
    image_bytes = _make_image_bytes()
    response = client.post(
        "/api/analyze",
        files={"image": ("test.jpg", image_bytes, "image/jpeg")},
        data={"question": "", "query_type": "auto"},
    )
    assert response.status_code == 400


def test_analyze_endpoint_rejects_bad_file_type():
    fake_pdf = io.BytesIO(b"%PDF-1.4 not a real pdf")
    response = client.post(
        "/api/analyze",
        files={"image": ("test.pdf", fake_pdf, "application/pdf")},
        data={"question": "Describe this", "query_type": "auto"},
    )
    assert response.status_code == 400


@patch("routes.analyze.query_vision_model", return_value=FAKE_MODEL_RESPONSE)
def test_compare_endpoint_full_pipeline(mock_query):
    img_a = _make_image_bytes(color=(30, 150, 30))   # greener
    img_b = _make_image_bytes(color=(180, 180, 180))  # neutral gray
    response = client.post(
        "/api/compare",
        files={
            "image_a": ("a.jpg", img_a, "image/jpeg"),
            "image_b": ("b.jpg", img_b, "image/jpeg"),
        },
        data={"question": "What changed?"},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["query_type_used"] == "comparison"
    assert data["quantitative"]["delta"]["vegetation_delta_pct"] <= 0  # vegetation should drop


def test_compare_endpoint_rejects_mismatched_aspect_ratio():
    img_a = _make_image_bytes(w=1600, h=400)
    img_b = _make_image_bytes(w=500, h=500)
    response = client.post(
        "/api/compare",
        files={
            "image_a": ("a.jpg", img_a, "image/jpeg"),
            "image_b": ("b.jpg", img_b, "image/jpeg"),
        },
        data={"question": "What changed?"},
    )
    assert response.status_code == 400


@patch("routes.analyze.query_vision_model", return_value=FAKE_MODEL_RESPONSE)
def test_analyze_region_endpoint(mock_query):
    image_bytes = _make_image_bytes(w=400, h=400)
    response = client.post(
        "/api/analyze-region",
        files={"image": ("test.jpg", image_bytes, "image/jpeg")},
        data={"question": "What is here?", "x1": 0, "y1": 0, "x2": 100, "y2": 100},
    )
    assert response.status_code == 200
    data = response.json()
    assert data["region_label"] == "upper-left"
