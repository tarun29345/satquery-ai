"""
tests/test_image_processor.py
--------------------------------
Tests resizing, large-image tiling, and the relative-region-labeling logic
(used for region-based analysis so we never claim real coordinates).
"""
import sys
import os
import numpy as np
from PIL import Image

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from services.image_processor import (
    resize_if_needed, needs_tiling, generate_tiles, get_relative_region_label,
)


def _solid_image(w, h):
    return Image.fromarray(np.zeros((h, w, 3), dtype=np.uint8), mode="RGB")


def test_resize_shrinks_oversized_image():
    img = _solid_image(5000, 3000)
    resized = resize_if_needed(img, max_dimension=1024)
    assert max(resized.size) == 1024
    # aspect ratio preserved (within rounding)
    assert abs((resized.size[0] / resized.size[1]) - (5000 / 3000)) < 0.01


def test_resize_leaves_small_image_untouched():
    img = _solid_image(400, 300)
    resized = resize_if_needed(img, max_dimension=4096)
    assert resized.size == (400, 300)


def test_needs_tiling_true_for_large_image():
    img = _solid_image(5000, 5000)
    assert needs_tiling(img) is True


def test_needs_tiling_false_for_normal_image():
    img = _solid_image(1024, 768)
    assert needs_tiling(img) is False


def test_generate_tiles_covers_whole_image():
    img = _solid_image(2000, 1500)
    tiles = generate_tiles(img, tile_size=800, overlap=64)
    assert len(tiles) > 1
    # Every tile's box should stay within image bounds
    for _, (x1, y1, x2, y2) in tiles:
        assert 0 <= x1 < x2 <= 2000
        assert 0 <= y1 < y2 <= 1500
    # The last tile in each row/column should reach the image edge
    max_x2 = max(box[2] for _, box in tiles)
    max_y2 = max(box[3] for _, box in tiles)
    assert max_x2 == 2000
    assert max_y2 == 1500


def test_region_label_upper_right():
    label = get_relative_region_label((800, 0, 1000, 200), full_size=(1000, 1000))
    assert "upper" in label and "right" in label


def test_region_label_central():
    label = get_relative_region_label((400, 400, 600, 600), full_size=(1000, 1000))
    assert label == "central region"
