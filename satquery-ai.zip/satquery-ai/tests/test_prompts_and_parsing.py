"""
tests/test_prompts_and_parsing.py
-----------------------------------
Tests the two most failure-prone pieces of the pipeline:
1. Query-type routing (does "is there a water body?" get the water prompt?)
2. Response parsing (can we reliably turn the model's text back into JSON,
   including when the model doesn't perfectly follow the format?)

No network calls - these use a hand-written fake model response.
"""
import sys
import os

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from prompts.templates import detect_query_type
from services.vision_service import parse_structured_response


def test_detect_query_type_water():
    assert detect_query_type("Is there a river or lake here?") == "water"


def test_detect_query_type_vegetation():
    assert detect_query_type("How much forest cover is visible?") == "vegetation"


def test_detect_query_type_urban():
    assert detect_query_type("Are there any roads or buildings?") == "urban"


def test_detect_query_type_general_fallback():
    assert detect_query_type("Describe this image") == "general"


def test_parse_well_formed_response():
    raw = """ANSWER: Yes, a water body is visible in the upper-right portion.
OBSERVATIONS: Smooth dark-blue region | Defined edge against land
FEATURES: water, vegetation
LOCATION: upper-right quadrant
CONFIDENCE: Medium"""
    result = parse_structured_response(raw)
    assert result["confidence"] == "Medium"
    assert "water" in result["features"]
    assert len(result["observations"]) == 2
    assert result["location"] == "upper-right quadrant"


def test_parse_malformed_response_degrades_gracefully():
    # Model ignored the format entirely - should NOT crash, should return
    # the raw text as the answer instead.
    raw = "This looks like a coastal area with some vegetation nearby."
    result = parse_structured_response(raw)
    assert result["answer"] == raw
    assert result["confidence"] == "Unknown"
    assert result["features"] == []


def test_parse_ignores_none_feature():
    raw = """ANSWER: No distinct features detected.
OBSERVATIONS: Uniform grey texture
FEATURES: none
LOCATION: not localized
CONFIDENCE: Low"""
    result = parse_structured_response(raw)
    assert result["features"] == []


def test_parse_invalid_confidence_falls_back_to_unknown():
    raw = """ANSWER: Test.
OBSERVATIONS: test
FEATURES: water
LOCATION: center
CONFIDENCE: Definitely"""
    result = parse_structured_response(raw)
    assert result["confidence"] == "Unknown"
