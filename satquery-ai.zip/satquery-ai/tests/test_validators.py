"""
tests/test_validators.py
--------------------------
Unit tests for input validation. These never call the AI API - they test
pure Python logic, so they run instantly and don't need a GEMINI_API_KEY.

Run all tests with:  pytest tests/ -v   (from the backend/ folder)
"""
import io
import sys
import os
import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "backend"))

from utils.validators import validate_question, validate_comparison_images, ValidationError


def test_empty_question_rejected():
    with pytest.raises(ValidationError):
        validate_question("")


def test_whitespace_only_question_rejected():
    with pytest.raises(ValidationError):
        validate_question("    ")


def test_valid_question_accepted():
    validate_question("Is there a water body?")  # should not raise


def test_overlong_question_rejected():
    with pytest.raises(ValidationError):
        validate_question("a" * 1001)


def test_comparison_similar_aspect_ratio_accepted():
    # Both roughly 4:3 - should pass without raising
    validate_comparison_images(800, 600, 820, 615)


def test_comparison_very_different_aspect_ratio_rejected():
    # One is wide-landscape, one is near-square - should be rejected
    with pytest.raises(ValidationError):
        validate_comparison_images(1600, 400, 500, 500)
