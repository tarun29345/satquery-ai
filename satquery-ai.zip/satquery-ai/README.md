# SatQuery AI

**SIH26167 — Interactive Vision-Language Assistant for Multimodal Remote Sensing Image Analysis through Text Queries**
Organization: ISRO · Team submission for Smart India Hackathon 2026

![Status](https://img.shields.io/badge/status-MVP%20working-brightgreen)
![Python](https://img.shields.io/badge/backend-Python%203.11%2B-blue)
![FastAPI](https://img.shields.io/badge/API-FastAPI-009688)
![React](https://img.shields.io/badge/frontend-React%20%2B%20Vite-61DAFB)
![Tests](https://img.shields.io/badge/tests-34%20passing-brightgreen)
![License](https://img.shields.io/badge/license-MIT-lightgrey)

Upload a satellite/aerial image, ask a question in plain English, get a grounded,
structured answer — backed by both a vision-language model **and** an independent
OpenCV pixel-classification layer, so answers come with real numbers, not just prose.
Also supports comparing two images of the same area to describe visible change.

This is a genuinely working system: images are actually sent to a vision-language
model (Google Gemini) and analyzed pixel-by-pixel with OpenCV. Nothing here is a
hardcoded or scripted demo response.

## Table of contents
- [Screenshots / demo](#screenshots--demo)
- [1. How it works (architecture)](#1-how-it-works-architecture)
- [2. Why Gemini Vision for the MVP](#2-why-gemini-vision-for-the-mvp-and-not-something-else)
- [3. Project structure](#3-project-structure)
- [4. Setup (Windows)](#4-setup-windows--exact-commands-beginner-friendly)
- [5. Running the automated tests](#5-running-the-automated-tests)
- [6. Manual test procedure](#6-manual-test-procedure)
- [7. Recommended datasets](#7-recommended-datasets-for-developmenttesting-images-and-future-training)
- [8. Evaluation framework](#8-evaluation-framework)
- [9. Known MVP limitations](#9-known-mvp-limitations-be-upfront-about-these-to-judges)
- [10. Roadmap](#10-roadmap--what-to-build-next-in-order)
- [11. Demo script](#11-demo-script-35-minutes)
- [12. Real-world use cases](#12-real-world-use-cases-to-mention-to-judges)
- [13. Likely judge questions](#13-likely-judge-questions)
- [14. Deploying for a live demo link](#14-deploying-for-a-live-demo-link)
- [Team](#team)
- [License](#license)

## Screenshots / demo

> Add your own screenshots before submitting — run the app locally (see
> [Setup](#4-setup-windows--exact-commands-beginner-friendly)), take a screenshot
> of the analyze view with a real result showing, save it into a new
> `docs/screenshots/` folder, then reference it here like this:
>
> `![Analyze view](docs/screenshots/analyze-view.png)`
>
> A short screen-recording GIF of the live demo (upload → ask → answer → compare)
> is the single highest-impact thing you can add — reviewers who never clone the
> repo will still see it genuinely works.

---

## 1. How it works (architecture)

```
React frontend (Vite)
        │  image + question, multipart/form-data
        ▼
FastAPI backend  ──►  validate file type/size
        │
        ▼
Image preprocessing (Pillow)  ──►  resize / crop / (tiling ready for large images)
        │
        ├─────────────────────────────┐
        ▼                              ▼
Prompt builder + Gemini Vision    OpenCV quantitative layer
(qualitative answer)              (vegetation / water / built-up %, independent of the AI)
        │                              │
        └──────────────┬───────────────┘
                        ▼
        JSON  ──►  React renders a structured "answer readout" card
                    with both the AI's answer AND the CV percentages
```

Every arrow above is a real file boundary in the code (see section 3), so any single
piece — the model, the prompts, the frontend, the CV layer — can be replaced without
touching the rest.

## 2. Why Gemini Vision for the MVP (and not something else)

| Approach | Why / why not |
|---|---|
| **Gemini Vision API (chosen)** | Free tier, no GPU needed, reliable during a live demo, genuinely handles aerial/satellite imagery reasonably well out of the box. |
| Self-hosted open-source VLM (LLaVA, Qwen-VL) | Needs a strong GPU most student laptops don't have; too fragile to depend on for a live judged demo. Good future upgrade if your college has GPU access. |
| Traditional CV / classifiers (EuroSAT-trained CNN etc.) | Can't answer open-ended questions on its own — this is why we run it **alongside** the VLM (see `services/cv_analysis.py`) rather than instead of it. |
| RS-specific research VLMs (GeoChat, RSGPT) | Immature tooling, high setup risk — not worth it for a 36-48hr build. |

The `services/vision_service.py` file is the **only** file that imports the Gemini SDK.
To swap models later, you only edit that one file.

## 3. Project structure

```
satquery-ai/
├── backend/
│   ├── main.py                  # FastAPI app entrypoint
│   ├── routes/analyze.py        # /api/analyze, /api/compare, /api/analyze-region
│   ├── services/
│   │   ├── vision_service.py    # ONLY file that talks to the Gemini AI model
│   │   ├── cv_analysis.py       # independent OpenCV vegetation/water/built-up estimator
│   │   └── image_processor.py   # resize, tiling, region-cropping
│   ├── prompts/templates.py     # all prompt engineering lives here
│   ├── utils/validators.py      # input validation, friendly error messages
│   ├── config/settings.py       # reads .env, single source of config
│   └── requirements.txt
├── frontend/
│   ├── src/
│   │   ├── App.jsx               # tab navigation (analyze / compare)
│   │   ├── api.js                 # the only file that calls the backend
│   │   └── components/            # UploadSlot, AnswerReadout, AnalyzeView, CompareView, HistoryLog
│   └── package.json
├── tests/                        # pytest suite — 34 tests, no API key needed to run
├── .env.example
├── .gitignore
└── README.md   (this file)
```

## 4. Setup (Windows) — exact commands, beginner-friendly

### Step 1 — Install Python
Download Python 3.11+ from https://python.org/downloads and during install,
**check "Add Python to PATH"**. Confirm it worked:
```
python --version
```

### Step 2 — Install Node.js
Download the LTS version from https://nodejs.org. Confirm:
```
node --version
npm --version
```

### Step 3 — Get a free Gemini API key
Go to https://aistudio.google.com/app/apikey → "Create API key" → copy it.
(This is free for the usage levels a hackathon demo needs.)

### Step 4 — Backend setup
```
cd satquery-ai\backend
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
copy ..\.env.example .env
```
Now open `backend\.env` in Notepad and paste your real key into `GEMINI_API_KEY=`.

Run the backend:
```
uvicorn main:app --reload --port 8000
```
Leave this terminal open. Visit http://localhost:8000/docs — if you see the FastAPI
docs page, the backend is alive. Visit http://localhost:8000/health — it should say
`"ai_configured": true` once your key is in place.

### Step 5 — Frontend setup (in a NEW terminal)
```
cd satquery-ai\frontend
npm install
npm run dev
```
Open the URL it prints (usually http://localhost:5173).

### Step 6 — Use it
1. Upload a satellite image (JPG/PNG/TIFF).
2. Type or click a suggested question.
3. Click "Analyze" and watch the structured answer *and* the vegetation/water/built-up
   percentages appear.
4. Try the "Compare two images" tab with two images of the same area.

## 5. Running the automated tests

The `tests/` folder has 34 tests covering validation, prompt routing, response
parsing, image preprocessing, the OpenCV quantitative layer, and full API routes
(with the AI call mocked, so no API key or internet is needed to run them):

```
cd satquery-ai\backend
pip install pytest httpx
cd ..
pytest tests/ -v
```
Expected output ends with `34 passed`. This is worth running right before your
demo and worth showing judges — it's proof the pipeline is actually tested, not
just "worked once on my laptop."

## 6. Manual test procedure

- **Sanity check**: upload any clear daytime aerial photo of a city or coastline
  and ask "Describe this image" — you should get a plausible, specific description,
  not a generic paragraph.
- **Water test**: use an image with a visible river/lake/coastline, ask
  "Is there a water body?" — answer should mention it and roughly where, and the
  water percentage bar should be non-trivial.
- **Error handling test**: try uploading a `.pdf` — you should get a clean
  "unsupported file type" message, not a crash.
- **Comparison test**: upload the same image twice as Image A and B, ask
  "what changed?" — the AI should say nothing significant changed, and the
  quantitative delta percentages should be at or near 0.

## 7. Recommended datasets (for development/testing images, and future training)

Start with **EuroSAT** first:
- **What**: 27,000 labeled Sentinel-2 patches across 10 land-cover classes
  (residential, industrial, river, forest, etc.)
- **Why first**: small (~2GB), clean, well-documented, perfect for quickly testing
  your pipeline end-to-end and for grabbing realistic sample images for your demo.
- **Format**: 64×64 RGB/multispectral GeoTIFF or JPEG patches.
- **Get it**: `https://github.com/phelber/EuroSAT` or via Hugging Face `datasets` (`eurosat`).
- **Preprocessing**: none needed for demo purposes beyond resizing up if you want
  a larger, more "satellite-like" looking demo image.

For later stages / stronger claims to judges:
- **UC Merced Land Use** — 21-class aerial imagery, good for land-cover Q&A variety.
- **LEVIR-CD** — building change-detection image pairs, ideal for stress-testing
  the comparison feature with real "before/after" pairs.
- **BigEarthNet** — large-scale multispectral (Sentinel-2), useful once you build
  real multispectral support (Phase 10).
- **SpaceNet** — building/road footprints, useful if you add object-detection overlays.

Don't download all of these — EuroSAT + a handful of LEVIR-CD pairs for the
comparison demo is enough for the hackathon.

## 8. Evaluation framework

Since this is a VLM-based system (not a classifier with fixed labels), measure:

- **Response latency** — already logged automatically in every API response (`latency_ms`).
- **VQA accuracy** — manually curate ~20 image+question+expected-answer pairs from
  EuroSAT/UC Merced (e.g. an image labeled "River" → question "is there a water body?"
  → expected "yes") and score how many the system gets right. This gives you a real,
  honest accuracy number for your presentation instead of an invented one.
- **Feature-detection precision/recall** — compare the `features` list the system
  returns against the dataset's ground-truth label for that image.
- **CV-layer sanity** — `tests/test_cv_analysis.py` already checks the OpenCV
  vegetation/water percentages against synthetic images with known ground truth;
  extend this with a handful of real EuroSAT patches for a genuine accuracy number.
- **Change-detection sanity** — the "same image twice → ~0% delta" test above is a
  simple, honest regression check, already automated in `test_routes_integration.py`.

Do not report numbers you haven't actually measured — an honest "on our 20-sample
test set we got X% VQA accuracy" is far more credible to judges than an invented 95%.

## 9. Known MVP limitations (be upfront about these to judges)

- Uses ordinary RGB imagery — no true multispectral (NIR/SWIR band) analysis yet.
- No true geo-referencing — the system never claims real-world coordinates by design.
- The OpenCV quantitative layer is a visible-band heuristic (VARI for vegetation,
  HSV thresholding for water) — not a calibrated NDVI/NDWI measurement, which would
  require near-infrared imagery. This is stated in the API response itself
  (`quantitative.disclaimer`), not hidden.
- Change detection combines AI interpretation with a coarse quantitative delta —
  it is not pixel-aligned, geometrically registered change detection.
- Requires an internet connection (cloud API) — see Phase 11 below for an offline path.

## 10. Roadmap — what to build next, in order

**Phase 9 — Quantitative backing — ✅ done.**
`services/cv_analysis.py` runs an OpenCV-based vegetation (VARI), water (HSV), and
built-up (edge-density) estimate alongside every VLM call, with a color-coded overlay
image, and is unit-tested against synthetic ground truth.

**Phase 10 — Multispectral support**
Swap Pillow for `rasterio` when the uploaded file is a multi-band GeoTIFF; extract
an RGB composite for the VLM call, and compute real NDVI from NIR+Red bands in
`cv_analysis.py`. `image_processor.py` is structured so this is a drop-in change.

**Phase 11 — Offline fallback**
Wrap `vision_service.py`'s call in a try/except that falls back to a small local
model (e.g. a quantized LLaVA via `ollama`) if the Gemini call fails — useful if
the venue's internet is unreliable during the demo. Only add this if you have
time to test it; an unreliable fallback is worse than none.

**Phase 12 — Large-image tiling**
`generate_tiles()` in `image_processor.py` is already implemented and unit-tested.
Wire it into `/api/analyze` when `needs_tiling()` is true: run the VLM on each tile,
then ask the VLM a final "synthesis" pass over the per-tile summaries.

## 11. Demo script (3–5 minutes)

1. Open the app, show the clean upload screen.
2. Upload a satellite image → ask "Describe this image" → show the structured answer
   **and** the vegetation/water/built-up percentage bars + overlay image.
3. Ask "Is there a water body?" then "Are there buildings?" — show it reasons per-question,
   not from a cached answer.
4. Switch to "Compare two images" → upload a before/after pair → ask "what changed?" →
   point out the AI's qualitative description AND the separate quantitative delta numbers.
5. Point at the architecture diagram (section 1) and explain the model-swap design,
   the dual AI+CV pipeline, and the honesty guardrails (no invented coordinates,
   explicit confidence, explicit "heuristic not calibrated" disclaimer).
6. Optionally run `pytest tests/ -v` live to show 34 passing tests.
7. Close with real-world use cases (below) and the roadmap.

## 12. Real-world use cases to mention to judges

Urban planning, flood/disaster assessment, agricultural monitoring, forest monitoring,
infrastructure monitoring, and general land-use interpretation for regions where
manual analyst review doesn't scale — explicitly **not** claiming production-readiness,
positioning this as an assistant that accelerates a human analyst's first pass.

## 13. Likely judge questions

**"How do you prevent hallucination?"** → Prompt guardrails force separation of
observation vs inference, explicit confidence levels, and a hard rule against
inventing coordinates/measurements — see `prompts/templates.py`.

**"Why not train your own model?"** → Time/data/compute constraints of a hackathon;
a general VLM with domain-specific prompting is the pragmatic MVP choice, backed by
an independent OpenCV layer for real numbers, with a clear roadmap (Phase 10) toward
true multispectral, remote-sensing-specific indices.

**"Does this work on real satellite data (multispectral, large scenes)?"** → Not yet —
that's an explicitly stated MVP limitation with a concrete, already-scaffolded
upgrade path (tiling and rasterio support are implemented and ready to wire in).

**"What's your accuracy?"** → Point to the evaluation framework (section 8) and
whatever real numbers you've measured by demo day — don't invent a number.

**"Is this actually tested?"** → Yes — `pytest tests/ -v` runs 34 tests covering
validation, prompt routing, response parsing, image preprocessing, the CV layer,
and full API routes end-to-end (AI call mocked so it runs without a live key).

## 14. Deploying for a live demo link

**Important: FastAPI cannot run on Vercel.** Vercel only serves static files and
short-lived serverless functions — it cannot host a persistent `uvicorn` process.
This project splits across two hosts:

| Part | Where | Why |
|---|---|---|
| Frontend (React/Vite) | **Vercel** | Static build, exactly what Vercel is for. |
| Backend (FastAPI) | **Render / Railway / Fly.io** (all have free tiers) | Needs a real persistent server, unlike Vercel. |

### Deploy the backend first (example: Render)
1. Push this repo to GitHub.
2. On Render: New → Web Service → point at your repo, **root directory** `backend`.
3. Build command: `pip install -r requirements.txt`
   Start command: `uvicorn main:app --host 0.0.0.0 --port $PORT`
4. Add environment variable `GEMINI_API_KEY` in Render's dashboard (never commit it).
5. Once deployed, copy the backend's URL (e.g. `https://satquery-backend.onrender.com`).

### Deploy the frontend on Vercel
1. New Project on Vercel → import this repo.
2. **Root Directory → set to `frontend`** (this is the #1 cause of a `NOT_FOUND`
   on the homepage — Vercel doesn't know the app lives in a subfolder otherwise).
3. Add environment variable `VITE_API_BASE_URL` = your backend URL from above.
4. Deploy. `frontend/vercel.json` handles client-side routing so refreshing a
   page doesn't 404.

### Verify
Visit `<your-backend-url>/health` directly — should return
`{"status": "ok", "ai_configured": true}`. If that 404s, the backend deploy
failed, not the frontend — check the backend host's build logs, not Vercel's.

## Team

<!-- Add your team details here for the SIH submission -->
| Name | Role | GitHub |
|---|---|---|
| _Your name_ | Team Lead | [@handle](https://github.com/) |
| _Teammate_ | _Role_ | [@handle](https://github.com/) |

## License

This project is licensed under the MIT License — see [LICENSE](LICENSE) for details.
