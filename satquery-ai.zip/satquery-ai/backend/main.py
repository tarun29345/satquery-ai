"""
main.py
-------
The entrypoint of the backend. Run this with:
    uvicorn main:app --reload --port 8000

What it does:
1. Creates the FastAPI app.
2. Enables CORS so the React frontend (on a different port) can call it.
3. Mounts the /api/analyze, /api/compare, /api/analyze-region routes.
4. Exposes a /health endpoint so you (and the judges) can quickly confirm
   the backend is alive.
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from config.settings import settings
from routes.analyze import router as analyze_router

app = FastAPI(
    title="SatQuery AI",
    description="Interactive Vision-Language Assistant for Remote Sensing Image Analysis",
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=settings.CORS_ORIGINS,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(analyze_router)


@app.get("/health")
async def health_check():
    """Simple liveness check. Also reports whether the AI key is configured,
    which is a very common source of confusing errors during setup."""
    return {
        "status": "ok",
        "ai_configured": bool(settings.GEMINI_API_KEY),
        "model": settings.GEMINI_MODEL,
    }


@app.get("/")
async def root():
    return {"message": "SatQuery AI backend is running. See /docs for the API explorer."}
