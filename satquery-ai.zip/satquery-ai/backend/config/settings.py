"""
config/settings.py
-------------------
Central place for all configuration values.
Reads secrets and tunables from environment variables (.env file) so that
nothing sensitive is ever hardcoded into the source code.

Every other backend file imports `settings` from here instead of calling
os.getenv() directly, so if you ever need to change a limit or add a new
config value, you only change it in ONE place.
"""

import os
from dotenv import load_dotenv

# Loads variables from a ".env" file (if present) into the process environment.
# This must run before we read any os.getenv() calls below.
load_dotenv()


class Settings:
    # --- AI model configuration ---
    GEMINI_API_KEY: str = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL: str = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")

    # --- Upload / image limits ---
    MAX_IMAGE_SIZE_MB: int = int(os.getenv("MAX_IMAGE_SIZE_MB", "20"))
    MAX_IMAGE_DIMENSION: int = int(os.getenv("MAX_IMAGE_DIMENSION", "4096"))  # px, longest side before we resize
    ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".tif", ".tiff"}

    # --- Server ---
    HOST: str = os.getenv("HOST", "0.0.0.0")
    PORT: int = int(os.getenv("PORT", "8000"))
    CORS_ORIGINS = os.getenv("CORS_ORIGINS", "http://localhost:5173").split(",")

    # --- Tiling (for large images, see services/image_processor.py) ---
    TILE_SIZE: int = int(os.getenv("TILE_SIZE", "1024"))
    TILE_THRESHOLD: int = int(os.getenv("TILE_THRESHOLD", "2048"))  # above this, we consider tiling


settings = Settings()

if not settings.GEMINI_API_KEY:
    # We don't crash on import (so the server can still start and show a clear
    # error to the frontend), but we print a loud warning so you notice it
    # immediately in the terminal.
    print(
        "\n⚠️  WARNING: GEMINI_API_KEY is not set. "
        "Copy .env.example to .env and add your key, or /analyze calls will fail.\n"
    )
