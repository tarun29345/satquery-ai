"""
routes/analyze.py
------------------
Defines the two core API endpoints:

  POST /api/analyze   -> single image + question  (Features 1-5, A, B, C)
  POST /api/compare    -> two images + question    (Feature D)
  POST /api/analyze-region -> single image + question + crop box (Feature E)

Each route follows the same pipeline:
  validate input -> preprocess image(s) -> build prompt -> call AI -> parse -> return JSON
"""

import time
from fastapi import APIRouter, UploadFile, File, Form, HTTPException

from utils.validators import (
    validate_image_file, validate_question, validate_comparison_images, ValidationError,
)
from services.image_processor import load_image_safely, resize_if_needed, get_relative_region_label
from services.vision_service import query_vision_model, parse_structured_response, VisionServiceError
from services.cv_analysis import compute_quantitative_layers, compute_change_delta
from prompts.templates import (
    PROMPT_ROUTER, detect_query_type, comparison_prompt, region_specific_prompt,
)

router = APIRouter(prefix="/api", tags=["analysis"])


@router.post("/analyze")
async def analyze_image(
    image: UploadFile = File(...),
    question: str = Form(...),
    query_type: str = Form(default="auto"),
):
    """
    Core MVP endpoint: Feature 1-5 from the brief.
    Accepts one image + one question, returns a structured AI answer.
    """
    start_time = time.time()

    try:
        validate_question(question)
        image_bytes = await image.read()
        validate_image_file(image, image_bytes)

        pil_image = load_image_safely(image_bytes)
        pil_image = resize_if_needed(pil_image)

        resolved_type = detect_query_type(question) if query_type == "auto" else query_type
        prompt_builder = PROMPT_ROUTER.get(resolved_type, PROMPT_ROUTER["general"])
        prompt = prompt_builder(question)

        raw_response = query_vision_model(prompt, [pil_image])
        result = parse_structured_response(raw_response)

        result["query_type_used"] = resolved_type
        result["latency_ms"] = round((time.time() - start_time) * 1000)

        # Independent CV pass - never let a CV failure break the AI answer.
        try:
            result["quantitative"] = compute_quantitative_layers(pil_image)
        except Exception:
            result["quantitative"] = None

        return result

    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except VisionServiceError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        # Catch-all so an unexpected error never returns a raw 500 traceback to the user.
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {e}")


@router.post("/compare")
async def compare_images(
    image_a: UploadFile = File(...),
    image_b: UploadFile = File(...),
    question: str = Form(default="What changed between these two images?"),
):
    """
    Feature D: two-image change comparison.
    """
    start_time = time.time()

    try:
        validate_question(question)

        bytes_a = await image_a.read()
        bytes_b = await image_b.read()
        validate_image_file(image_a, bytes_a)
        validate_image_file(image_b, bytes_b)

        pil_a = load_image_safely(bytes_a)
        pil_b = load_image_safely(bytes_b)

        validate_comparison_images(pil_a.width, pil_a.height, pil_b.width, pil_b.height)

        pil_a = resize_if_needed(pil_a)
        pil_b = resize_if_needed(pil_b)

        prompt = comparison_prompt(question)
        raw_response = query_vision_model(prompt, [pil_a, pil_b])
        result = parse_structured_response(raw_response)

        result["query_type_used"] = "comparison"
        result["latency_ms"] = round((time.time() - start_time) * 1000)

        # Independent quantitative change delta - kept explicitly separate
        # from the VLM's qualitative interpretation above (see cv_analysis.py).
        try:
            layers_a = compute_quantitative_layers(pil_a)
            layers_b = compute_quantitative_layers(pil_b)
            result["quantitative"] = {
                "image_a": layers_a,
                "image_b": layers_b,
                "delta": compute_change_delta(layers_a, layers_b),
            }
        except Exception:
            result["quantitative"] = None

        return result

    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except VisionServiceError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {e}")


@router.post("/analyze-region")
async def analyze_region(
    image: UploadFile = File(...),
    question: str = Form(...),
    x1: int = Form(...),
    y1: int = Form(...),
    x2: int = Form(...),
    y2: int = Form(...),
):
    """
    Feature E: region-based analysis. The frontend lets the user draw a crop
    box on the displayed image and sends its pixel coordinates here. We crop
    the ORIGINAL image server-side (never trust frontend-cropped pixels blindly)
    and describe the region's position only in relative terms.
    """
    start_time = time.time()

    try:
        validate_question(question)
        image_bytes = await image.read()
        validate_image_file(image, image_bytes)

        pil_image = load_image_safely(image_bytes)
        full_size = pil_image.size

        x1, y1 = max(0, x1), max(0, y1)
        x2, y2 = min(full_size[0], x2), min(full_size[1], y2)
        if x2 <= x1 or y2 <= y1:
            raise ValidationError("Invalid region selected. Please draw a valid box on the image.")

        region_label = get_relative_region_label((x1, y1, x2, y2), full_size)
        cropped = pil_image.crop((x1, y1, x2, y2))
        cropped = resize_if_needed(cropped)

        prompt = region_specific_prompt(question, region_label)
        raw_response = query_vision_model(prompt, [cropped])
        result = parse_structured_response(raw_response)

        result["query_type_used"] = "region_specific"
        result["region_label"] = region_label
        result["latency_ms"] = round((time.time() - start_time) * 1000)

        try:
            result["quantitative"] = compute_quantitative_layers(cropped)
        except Exception:
            result["quantitative"] = None

        return result

    except ValidationError as e:
        raise HTTPException(status_code=400, detail=str(e))
    except VisionServiceError as e:
        raise HTTPException(status_code=502, detail=str(e))
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Unexpected server error: {e}")
