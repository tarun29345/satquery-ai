"""
utils/validators.py
--------------------
All input-validation logic lives here so that routes/analyze.py stays clean.

Every function either returns silently (input is fine) or raises a
`ValidationError` with a message that is SAFE and CLEAR to show directly
to the end user in the frontend (see section 19/20 of the brief:
error handling + security).
"""

import os
from fastapi import UploadFile
from config.settings import settings


class ValidationError(Exception):
    """Raised whenever user input fails validation. The message is user-facing."""
    pass


def validate_image_file(file: UploadFile, file_bytes: bytes) -> None:
    """
    Validates an uploaded image before it ever touches the AI pipeline.

    Checks (in order):
    1. Extension is an allowed image type (prevents arbitrary file upload).
    2. File size is within the configured limit (prevents memory/DoS issues
       and avoids sending huge payloads to the AI API).
    3. File is not empty / corrupted at the byte level.
    """
    if file is None or file.filename is None:
        raise ValidationError("No file was uploaded.")

    ext = os.path.splitext(file.filename)[1].lower()
    if ext not in settings.ALLOWED_EXTENSIONS:
        raise ValidationError(
            f"Unsupported file type '{ext}'. "
            f"Please upload one of: {', '.join(sorted(settings.ALLOWED_EXTENSIONS))}"
        )

    size_mb = len(file_bytes) / (1024 * 1024)
    if size_mb > settings.MAX_IMAGE_SIZE_MB:
        raise ValidationError(
            f"Image is {size_mb:.1f}MB, which exceeds the {settings.MAX_IMAGE_SIZE_MB}MB limit. "
            "Please upload a smaller image or compress it first."
        )

    if len(file_bytes) == 0:
        raise ValidationError("The uploaded file is empty or corrupted.")


def validate_question(question: str) -> None:
    """Ensures the user actually asked something."""
    if question is None or question.strip() == "":
        raise ValidationError("Please type a question about the image.")
    if len(question) > 1000:
        raise ValidationError("Question is too long (max 1000 characters).")


def validate_comparison_images(width_a: int, height_a: int, width_b: int, height_b: int) -> None:
    """
    For the comparison feature: warns (does not block) if the two images have
    very different aspect ratios, since that usually means they cover
    different areas/zoom levels and a direct visual comparison will mislead
    more than help. We raise a soft error so the user can still proceed if
    they confirm, but for MVP simplicity we just block with a clear message.
    """
    ratio_a = width_a / height_a
    ratio_b = width_b / height_b
    if abs(ratio_a - ratio_b) > 0.35:
        raise ValidationError(
            "The two images have very different aspect ratios / framing, "
            "which usually means they cover different areas. "
            "For meaningful comparison, upload two images of the same area/extent."
        )
