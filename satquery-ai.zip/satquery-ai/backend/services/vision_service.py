"""
services/vision_service.py
----------------------------
This is the ONLY file that talks to the actual AI model. Everything else in
the backend works with plain Python objects (parsed dicts), never with the
Gemini SDK directly. That means:

  - If you swap Gemini for another model (open-source LLaVA/Qwen-VL, or a
    different cloud API) later, you only ever edit THIS file.
  - Routes and prompt templates never change.

This satisfies the brief's requirement (section 6) to "isolate the API
integration inside a clean service/module so the model can later be replaced."
"""

import re
from typing import List, Optional
import google.generativeai as genai
from PIL import Image

from config.settings import settings

# Configure the Gemini SDK once, at import time, using the API key from settings.
if settings.GEMINI_API_KEY:
    genai.configure(api_key=settings.GEMINI_API_KEY)


class VisionServiceError(Exception):
    """Raised when the AI call fails for any reason. Message is user-facing."""
    pass


def _get_model():
    if not settings.GEMINI_API_KEY:
        raise VisionServiceError(
            "The AI service is not configured (missing GEMINI_API_KEY on the server). "
            "Ask the team member running the backend to add it to backend/.env"
        )
    return genai.GenerativeModel(settings.GEMINI_MODEL)


def query_vision_model(prompt: str, images: List[Image.Image]) -> str:
    """
    Sends one prompt + one or more images to the vision-language model and
    returns the RAW text response.

    `images` is a list because comparison mode sends two images in one call;
    general analysis sends a list of length 1.
    """
    model = _get_model()
    try:
        # The Gemini SDK accepts a list mixing text and PIL Image objects directly.
        content = [prompt] + images
        response = model.generate_content(content)

        if not response or not getattr(response, "text", None):
            raise VisionServiceError(
                "The AI model returned an empty response. This can happen if the image "
                "was flagged by the provider's safety filters, or the model is temporarily "
                "unavailable. Please try again or use a different image."
            )
        return response.text

    except VisionServiceError:
        raise
    except Exception as exc:
        # Any SDK/network/auth error lands here. We never leak raw stack traces
        # or the API key to the frontend - just a clear, safe message.
        raise VisionServiceError(f"AI service request failed: {exc}")


def parse_structured_response(raw_text: str) -> dict:
    """
    Parses the model's structured plain-text response (see prompts/templates.py
    for the exact format we ask for) into a clean dict for the frontend:

        {
            "answer": str,
            "observations": [str, ...],
            "features": [str, ...],
            "location": str,
            "confidence": "High" | "Medium" | "Low" | "Unknown"
        }

    Designed to degrade gracefully: if the model doesn't perfectly follow the
    format (LLMs sometimes don't), we still return whatever we can extract
    instead of crashing, and put the rest of the raw text into "answer" so
    nothing is lost.
    """

    def _extract(label: str) -> Optional[str]:
        # Matches "LABEL: <value up to the next known LABEL or end of string>"
        pattern = rf"{label}:\s*(.*?)(?=\n[A-Z_]+:|\Z)"
        match = re.search(pattern, raw_text, re.DOTALL | re.IGNORECASE)
        return match.group(1).strip() if match else None

    answer = _extract("ANSWER")
    observations_raw = _extract("OBSERVATIONS")
    features_raw = _extract("FEATURES")
    location = _extract("LOCATION")
    confidence = _extract("CONFIDENCE")

    if not answer:
        # The model didn't follow the format at all - fall back to returning
        # the whole raw text as the answer so the user still gets something useful.
        return {
            "answer": raw_text.strip(),
            "observations": [],
            "features": [],
            "location": "not specified",
            "confidence": "Unknown",
        }

    observations = (
        [o.strip() for o in observations_raw.split("|") if o.strip()]
        if observations_raw else []
    )
    features = (
        [f.strip() for f in features_raw.split(",") if f.strip() and f.strip().lower() != "none"]
        if features_raw else []
    )
    confidence_clean = confidence.strip().capitalize() if confidence else "Unknown"
    if confidence_clean not in ("High", "Medium", "Low"):
        confidence_clean = "Unknown"

    return {
        "answer": answer,
        "observations": observations,
        "features": features,
        "location": location or "not specified",
        "confidence": confidence_clean,
    }
