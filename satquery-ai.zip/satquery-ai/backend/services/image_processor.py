"""
services/image_processor.py
----------------------------
Handles everything that needs to happen to an image BEFORE it reaches the AI
model: safe loading, resizing, and (for very large images) tiling.

WHY TILING MATTERS (see brief section 8):
Satellite images can be extremely large (a real satellite scene can be
tens of thousands of pixels wide). Vision-language APIs have:
  - a maximum image size/resolution they will accept,
  - a token-cost that scales with resolution,
  - and actually get LESS accurate on tiny/downsized details when a huge
    image is squashed down to fit their limits.
So instead of blindly shrinking a huge image (and losing detail like small
buildings or thin roads), we split it into overlapping tiles, so each tile
sent to the model has a reasonable resolution. For the MVP we implement the
tiling utility itself and use it for the "describe/analyze whole image"
flow only when the image exceeds TILE_THRESHOLD; by default the MVP simply
resizes normal-sized images (a typical demo image), and tiling is there,
tested, and ready for the multispectral/large-image upgrade path.
"""

import io
from typing import List, Tuple
from PIL import Image, ImageOps
from config.settings import settings


def load_image_safely(file_bytes: bytes) -> Image.Image:
    """
    Loads image bytes into a Pillow Image object.
    - Fixes orientation using EXIF data (common issue with phone/drone photos).
    - Converts to RGB (some satellite exports are RGBA, palette-based, or CMYK,
      which some AI APIs reject).
    Raises ValueError with a friendly message if the file is not a valid image.
    """
    try:
        image = Image.open(io.BytesIO(file_bytes))
        image = ImageOps.exif_transpose(image)  # respect camera/sensor orientation
        image = image.convert("RGB")
        return image
    except Exception as exc:
        raise ValueError(f"Could not read this file as an image. It may be corrupted. ({exc})")


def resize_if_needed(image: Image.Image, max_dimension: int = None) -> Image.Image:
    """
    Downscales the image so its longest side does not exceed max_dimension,
    preserving aspect ratio. Most vision APIs don't need more resolution than
    this for a good answer, and it keeps requests fast and within API limits.
    """
    max_dimension = max_dimension or settings.MAX_IMAGE_DIMENSION
    width, height = image.size
    longest_side = max(width, height)

    if longest_side <= max_dimension:
        return image  # already small enough

    scale = max_dimension / longest_side
    new_size = (int(width * scale), int(height * scale))
    return image.resize(new_size, Image.LANCZOS)


def needs_tiling(image: Image.Image) -> bool:
    """An image is a 'large image' candidate for tiling above this threshold."""
    return max(image.size) > settings.TILE_THRESHOLD


def generate_tiles(image: Image.Image, tile_size: int = None, overlap: int = 64) -> List[Tuple[Image.Image, Tuple[int, int, int, int]]]:
    """
    Splits a large image into overlapping square tiles.

    Returns a list of (tile_image, (x_start, y_start, x_end, y_end)) so callers
    know where each tile sits within the original image (needed to describe
    "location" of a feature relative to the whole scene, without ever claiming
    real-world geo-coordinates).

    Overlap prevents features from being cut cleanly in half at tile boundaries
    (e.g. a river running exactly along a tile edge).

    NOTE (MVP scope): the /analyze route does not call this yet for the demo
    flow (Gemini handles the typical demo-sized images directly and more
    cheaply/reliably). This function is provided, tested, and ready to wire in
    for "Phase 9: large multispectral scene support" — see the roadmap in
    the README for how to plug it into vision_service.py.
    """
    tile_size = tile_size or settings.TILE_SIZE
    width, height = image.size
    tiles = []

    y = 0
    while y < height:
        x = 0
        while x < width:
            x_end = min(x + tile_size, width)
            y_end = min(y + tile_size, height)
            tile = image.crop((x, y, x_end, y_end))
            tiles.append((tile, (x, y, x_end, y_end)))
            if x_end == width:
                break
            x += tile_size - overlap
        if y_end == height:
            break
        y += tile_size - overlap

    return tiles


def image_to_bytes(image: Image.Image, fmt: str = "JPEG") -> bytes:
    """Serializes a Pillow image back to bytes (needed before sending to the AI API)."""
    buffer = io.BytesIO()
    image.save(buffer, format=fmt, quality=90)
    return buffer.getvalue()


def get_relative_region_label(crop_box: Tuple[int, int, int, int], full_size: Tuple[int, int]) -> str:
    """
    Given a crop box (x1, y1, x2, y2) and the full image size, returns a plain
    relative-position label like "upper-right quadrant". Used for Feature E
    (region-based analysis) so the prompt can describe location without ever
    inventing real coordinates.
    """
    x1, y1, x2, y2 = crop_box
    full_w, full_h = full_size
    cx, cy = (x1 + x2) / 2, (y1 + y2) / 2

    horiz = "left" if cx < full_w / 3 else "right" if cx > 2 * full_w / 3 else "center"
    vert = "upper" if cy < full_h / 3 else "lower" if cy > 2 * full_h / 3 else "middle"

    if horiz == "center" and vert == "middle":
        return "central region"
    if vert == "middle":
        return f"middle-{horiz}"
    if horiz == "center":
        return f"{vert}-center"
    return f"{vert}-{horiz}"
