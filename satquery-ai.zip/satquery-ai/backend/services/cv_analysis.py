"""
services/cv_analysis.py
------------------------
This module adds a SECOND, independent analysis path that does not depend on
the vision-language model at all: classic computer-vision heuristics that
estimate land-cover proportions directly from pixel values.

WHY THIS EXISTS (see brief section 9 and the SIH-judge perspective):
A vision-language model gives a qualitative, language-based answer. It cannot
tell you "38% of this frame is vegetation" - it can only say "there appears to
be substantial vegetation." Judges specifically distinguish "AI interpretation"
from "quantitative change detection." This module is the quantitative half:
plain OpenCV/NumPy pixel classification, fully deterministic, with zero API
calls, that runs alongside the VLM and gives real numbers to back up (or
sanity-check) what the VLM says.

HONESTY NOTE (important - do not oversell this in the demo):
This is a heuristic, visible-band-only estimate. True vegetation indices like
NDVI require a near-infrared band, which ordinary RGB images/screenshots do
not have. We approximate using a well-established VISIBLE-BAND vegetation
index (VARI - Visible Atmospherically Resistant Index), which is a standard,
documented substitute for NDVI when only RGB is available. Always describe
this as "indicative" in the UI, never as a calibrated scientific measurement.
"""

import base64
import io
from typing import Dict

import cv2
import numpy as np
from PIL import Image


def _pil_to_bgr(image: Image.Image) -> np.ndarray:
    """Converts a PIL RGB image to an OpenCV-style BGR NumPy array."""
    rgb = np.array(image.convert("RGB"))
    return cv2.cvtColor(rgb, cv2.COLOR_RGB2BGR)


def _water_mask(bgr: np.ndarray) -> np.ndarray:
    """
    Water typically appears as a smooth region that is either:
      - blue-ish with moderate-to-high saturation (clear water, pools, sea), or
      - dark and low-saturation (murky water, shadowed water, some lakes).
    We combine both conditions in HSV space. This is a heuristic, not a
    calibrated water index (that would be NDWI, which needs a NIR/SWIR band).
    """
    hsv = cv2.cvtColor(bgr, cv2.COLOR_BGR2HSV)
    h, s, v = hsv[:, :, 0], hsv[:, :, 1], hsv[:, :, 2]

    blueish = (h >= 90) & (h <= 140) & (s >= 40)
    dark_flat = (v < 60) & (s < 60)

    mask = (blueish | dark_flat).astype(np.uint8) * 255
    # Morphological opening removes single-pixel noise (e.g. dark shadow specks
    # under buildings) so we only count reasonably contiguous water regions.
    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    return mask


def _vegetation_mask(bgr: np.ndarray) -> np.ndarray:
    """
    VARI = (Green - Red) / (Green + Red - Blue)
    A standard visible-band proxy for vegetation "greenness" used when a
    near-infrared band (required for true NDVI) is not available.
    Higher VARI = more likely vegetation.
    """
    b = bgr[:, :, 0].astype(np.float32)
    g = bgr[:, :, 1].astype(np.float32)
    r = bgr[:, :, 2].astype(np.float32)

    denominator = (g + r - b)
    denominator[denominator == 0] = 1e-6  # avoid divide-by-zero
    vari = (g - r) / denominator

    mask = (vari > 0.05).astype(np.uint8) * 255
    kernel = np.ones((3, 3), np.uint8)
    mask = cv2.morphologyEx(mask, cv2.MORPH_OPEN, kernel)
    return mask, vari


def _built_up_mask(bgr: np.ndarray, exclude_mask: np.ndarray) -> np.ndarray:
    """
    Built-up / urban areas tend to have high local edge density (rooftops,
    roads, building boundaries create lots of straight edges close together),
    whereas natural bare land and open fields are comparatively smooth.
    We compute edge density in local blocks and flag high-edge-density,
    non-vegetation, non-water blocks as "built-up".
    """
    gray = cv2.cvtColor(bgr, cv2.COLOR_BGR2GRAY)
    edges = cv2.Canny(gray, 50, 150)

    block = 16
    h, w = edges.shape
    density_map = np.zeros_like(edges, dtype=np.float32)
    for y in range(0, h, block):
        for x in range(0, w, block):
            patch = edges[y:y + block, x:x + block]
            if patch.size == 0:
                continue
            density = np.mean(patch > 0)
            density_map[y:y + block, x:x + block] = density

    built_up = (density_map > 0.12).astype(np.uint8) * 255
    built_up = cv2.bitwise_and(built_up, cv2.bitwise_not(exclude_mask))
    return built_up


def compute_quantitative_layers(image: Image.Image, max_side: int = 512) -> Dict:
    """
    Main entry point. Runs all heuristic masks on a downsized copy of the
    image (for speed - percentages are scale-invariant), returns:

    {
        "vegetation_pct": float,
        "water_pct": float,
        "built_up_pct": float,
        "other_pct": float,
        "overlay_image_base64": "data:image/png;base64,....",
        "method": "heuristic-rgb",         # signals this is NOT calibrated NDVI/NDWI
        "disclaimer": "..."
    }
    """
    working = image.copy()
    working.thumbnail((max_side, max_side))
    bgr = _pil_to_bgr(working)

    water = _water_mask(bgr)
    vegetation, _ = _vegetation_mask(bgr)
    # Water takes priority over vegetation in overlapping pixels (e.g. algae-green water)
    vegetation = cv2.bitwise_and(vegetation, cv2.bitwise_not(water))

    combined_natural = cv2.bitwise_or(water, vegetation)
    built_up = _built_up_mask(bgr, exclude_mask=combined_natural)

    total_pixels = bgr.shape[0] * bgr.shape[1]

    def pct(mask):
        return round(100.0 * np.count_nonzero(mask) / total_pixels, 1)

    water_pct = pct(water)
    veg_pct = pct(vegetation)
    built_pct = pct(built_up)
    other_pct = round(max(0.0, 100.0 - water_pct - veg_pct - built_pct), 1)

    overlay = bgr.copy()
    overlay[water > 0] = (0.5 * overlay[water > 0] + 0.5 * np.array([200, 60, 20])).astype(np.uint8)      # blue-ish tint (BGR)
    overlay[vegetation > 0] = (0.5 * overlay[vegetation > 0] + 0.5 * np.array([40, 160, 60])).astype(np.uint8)  # green tint
    overlay[built_up > 0] = (0.5 * overlay[built_up > 0] + 0.5 * np.array([50, 90, 200])).astype(np.uint8)      # amber/red tint

    overlay_rgb = cv2.cvtColor(overlay, cv2.COLOR_BGR2RGB)
    overlay_pil = Image.fromarray(overlay_rgb)
    buf = io.BytesIO()
    overlay_pil.save(buf, format="PNG")
    overlay_b64 = "data:image/png;base64," + base64.b64encode(buf.getvalue()).decode("ascii")

    return {
        "vegetation_pct": veg_pct,
        "water_pct": water_pct,
        "built_up_pct": built_pct,
        "other_pct": other_pct,
        "overlay_image_base64": overlay_b64,
        "method": "heuristic-rgb",
        "disclaimer": (
            "Indicative estimate from visible-band (RGB) pixel classification only. "
            "Not a calibrated NDVI/NDWI measurement - true spectral indices require "
            "near-infrared imagery."
        ),
    }


def compute_change_delta(layers_a: Dict, layers_b: Dict) -> Dict:
    """
    Given the quantitative layers for two images (same area, ideally same
    extent), returns the numeric delta per category. This is the genuinely
    "quantitative" half of change detection, kept separate from and alongside
    the VLM's qualitative interpretation - never blended into one number so
    the two remain clearly distinguishable, per the brief's requirement.
    """
    return {
        "vegetation_delta_pct": round(layers_b["vegetation_pct"] - layers_a["vegetation_pct"], 1),
        "water_delta_pct": round(layers_b["water_pct"] - layers_a["water_pct"], 1),
        "built_up_delta_pct": round(layers_b["built_up_pct"] - layers_a["built_up_pct"], 1),
    }
